//
//  HomeViewController.m
//  ProiectDani
//
//  Created by Viorel Radu on 10/12/13.
//  Copyright (c) 2013 UPB. All rights reserved.
//

#import "HomeViewController.h"
#import "AdmitereViewController.h"

@interface HomeViewController ()
@property (weak, nonatomic) IBOutlet UILabel *headerLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headerImage;
@property (weak, nonatomic) IBOutlet UILabel *loadedViewControllerNameLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *languageSelector;

@property (strong, nonatomic) NSArray *languages;

@end

@implementation HomeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _languages = @[@"Romana", @"English",
                       @"French", @"Deutsch"];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    _languages = @[@"Romana", @"English",
                   @"French", @"Deutsch"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.destinationViewController isKindOfClass:[AdmitereViewController class]]) {
       // AdmitereViewController *admitereVC = (AdmitereViewController*)segue.destinationViewController;
    }
}

#pragma mark -
#pragma mark PickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    return _languages.count;
}

- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    return _languages[row];
}

#pragma mark -
#pragma mark PickerView Delegate
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    // To be defined
    // Change language
}


@end
