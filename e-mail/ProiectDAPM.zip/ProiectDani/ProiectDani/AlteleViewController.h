//
//  AlteleViewController.h
//  ProiectDani
//
//  Created by Viorel Radu on 11/12/13.
//  Copyright (c) 2013 UPB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlteleViewController : UIViewController

@end
